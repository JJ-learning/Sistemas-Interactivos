# This program has to be managed using the following steps:
    1. Turn on the application using the button 'Encender'
    2. Reload the images using the button 'Cargar Imagenes'
    3. Then use 'Siguiente' and 'Anterior' button in order to move through the app.

#### The user can set the number of images diplayed. It must be smaller than 9 and greater than 0.